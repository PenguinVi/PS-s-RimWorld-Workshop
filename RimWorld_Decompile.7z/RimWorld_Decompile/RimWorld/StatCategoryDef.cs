using Verse;

namespace RimWorld
{
	public class StatCategoryDef : Def
	{
		public int displayOrder;

		public bool displayAllByDefault;
	}
}
