namespace RimWorld
{
	public interface IBillGiverWithTickAction : IBillGiver
	{
		void UsedThisTick();
	}
}
