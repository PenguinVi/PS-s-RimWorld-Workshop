namespace RimWorld
{
	public class StorytellerCompProperties_DeepDrillInfestation : StorytellerCompProperties
	{
		public float baseMtbDaysPerDrill;

		public StorytellerCompProperties_DeepDrillInfestation()
		{
			compClass = typeof(StorytellerComp_DeepDrillInfestation);
		}
	}
}
