namespace RimWorld
{
	public class Instruction_Basic : Lesson_Instruction
	{
	}
}
