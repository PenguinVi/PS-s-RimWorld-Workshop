namespace RimWorld
{
	public enum ShieldState : byte
	{
		Active,
		Resetting
	}
}
