namespace RimWorld
{
	public enum TraderCaravanRole
	{
		None,
		Trader,
		Carrier,
		Guard,
		Chattel
	}
}
