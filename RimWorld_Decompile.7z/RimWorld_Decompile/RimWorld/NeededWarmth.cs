namespace RimWorld
{
	public enum NeededWarmth : byte
	{
		Any,
		Warm,
		Cool
	}
}
