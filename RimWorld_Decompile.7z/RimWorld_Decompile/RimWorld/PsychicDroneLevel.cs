namespace RimWorld
{
	public enum PsychicDroneLevel : byte
	{
		None,
		GoodMedium,
		BadLow,
		BadMedium,
		BadHigh,
		BadExtreme
	}
}
