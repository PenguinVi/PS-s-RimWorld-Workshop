namespace Verse.AI.Group
{
	public abstract class TransitionAction
	{
		public abstract void DoAction(Transition trans);
	}
}
