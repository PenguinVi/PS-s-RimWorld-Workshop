using Verse;

namespace RimWorld
{
	public class PrisonerInteractionModeDef : Def
	{
		public int listOrder;
	}
}
