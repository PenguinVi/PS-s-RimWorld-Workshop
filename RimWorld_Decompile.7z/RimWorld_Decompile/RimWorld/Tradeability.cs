namespace RimWorld
{
	public enum Tradeability : byte
	{
		None,
		Sellable,
		Buyable,
		All
	}
}
