namespace RimWorld
{
	public enum TransferAsOneMode
	{
		Normal,
		PodsOrCaravanPacking,
		InactiveTradeable
	}
}
