namespace Verse.AI.Group
{
	public class LordToil_End : LordToil
	{
		public override bool ShouldFail => true;

		public override void UpdateAllDuties()
		{
		}
	}
}
