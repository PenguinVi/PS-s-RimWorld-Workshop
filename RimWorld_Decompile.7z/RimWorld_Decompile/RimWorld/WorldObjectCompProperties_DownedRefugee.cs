using RimWorld.Planet;

namespace RimWorld
{
	public class WorldObjectCompProperties_DownedRefugee : WorldObjectCompProperties
	{
		public WorldObjectCompProperties_DownedRefugee()
		{
			compClass = typeof(DownedRefugeeComp);
		}
	}
}
