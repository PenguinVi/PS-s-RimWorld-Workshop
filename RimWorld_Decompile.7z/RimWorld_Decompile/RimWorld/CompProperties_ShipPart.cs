using Verse;

namespace RimWorld
{
	public class CompProperties_ShipPart : CompProperties
	{
		public CompProperties_ShipPart()
		{
			compClass = typeof(CompShipPart);
		}
	}
}
