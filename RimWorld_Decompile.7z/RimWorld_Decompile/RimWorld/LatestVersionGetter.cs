using UnityEngine;

namespace RimWorld
{
	public class LatestVersionGetter : MonoBehaviour
	{
		public void DrawAt(Rect rect)
		{
		}
	}
}
