namespace Verse.AI.Group
{
	public abstract class LordToilData : IExposable
	{
		public abstract void ExposeData();
	}
}
