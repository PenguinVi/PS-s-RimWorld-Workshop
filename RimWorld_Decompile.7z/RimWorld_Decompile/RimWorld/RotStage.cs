namespace RimWorld
{
	public enum RotStage : byte
	{
		Fresh,
		Rotting,
		Dessicated
	}
}
