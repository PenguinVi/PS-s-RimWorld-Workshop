namespace Verse.AI.Group
{
	public abstract class TriggerData : IExposable
	{
		public abstract void ExposeData();
	}
}
