namespace RimWorld
{
	public static class NeedTunings
	{
		public const int NeedUpdateInterval = 150;
	}
}
