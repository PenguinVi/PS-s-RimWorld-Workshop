namespace RimWorld
{
	public enum TechLevel : byte
	{
		Undefined,
		Animal,
		Neolithic,
		Medieval,
		Industrial,
		Spacer,
		Ultra,
		Archotech
	}
}
