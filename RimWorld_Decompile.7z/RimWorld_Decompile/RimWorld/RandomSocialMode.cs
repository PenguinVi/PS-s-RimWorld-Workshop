namespace RimWorld
{
	public enum RandomSocialMode
	{
		Off,
		Quiet,
		Normal,
		SuperActive
	}
}
