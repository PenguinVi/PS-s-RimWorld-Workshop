namespace RimWorld
{
	public enum Transactor : byte
	{
		Colony,
		Trader
	}
}
